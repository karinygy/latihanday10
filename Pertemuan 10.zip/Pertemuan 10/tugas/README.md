# latihanday10
JMP A DTS 2022 day 10
